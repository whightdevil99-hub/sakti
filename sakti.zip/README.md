# ⚡ SAKTI - AI Voice Assistant (Jarvis & Hermes Architecture)

SAKTI is a futuristic, hybrid-brain AI assistant built in Flutter, inspired by **Jarvis**, **Alexa**, and **Hermes**.

---

## 🌟 Key Features

1. **Hybrid Brain**:
   - **Local Engine (Offline)**: Fast, zero-latency system actions (Torch on/off, Battery stats, Time, Date, Launching apps like YouTube & WhatsApp).
   - **Hermes Custom Skills Engine**: User-defined custom voice skills, IoT/Home Assistant REST webhooks, and trigger phrases with offline persistence (`shared_preferences`).
   - **Self-Improving Neural Memory Engine**: Autonomous fact learning, user preference tracking, behavioral corrections memory, and adaptive dynamic prompt injection into Gemini LLM.
   - **Cloud Engine (Gemini 1.5 Flash)**: Complex conversational reasoning, knowledge retrieval, and automatic **Function Calling / Tool Calling**.
2. **Futuristic Jarvis HUD Interface**:
   - **Pulsating Holographic Reactor Orb**: Dynamic rotating concentric HUD rings with reactive glow states (`idle`, `listening`, `thinking`, `speaking`).
   - **Live Audio Waveform**: Animated real-time sound frequency bars.
   - **Hologram Telemetry Card**: Live transcription of Boss commands and SAKTI spoken output with executed action badges.
   - **Tactical Quick Action Deck**: One-tap shortcuts for immediate flashlight, battery, and utility control.
3. **Voice & Audio Ready**:
   - Integrated with `porcupine_flutter` (Wake Word), `speech_to_text` (STT), and `flutter_tts` (TTS).

---

## 🚀 Getting Started

### 1. Android Permissions (`android/app/src/main/AndroidManifest.xml`)
Add the following permissions to your `AndroidManifest.xml`:

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.FLASHLIGHT" />
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />

    <application ...>
        ...
    </application>
</manifest>
```

### 2. Install Dependencies
```bash
flutter pub get
```

### 3. Run SAKTI
```bash
flutter run
```

### 4. Neural Configuration
- Tap the **Settings** icon on the top right of the SAKTI HUD.
- Enter your **Google Gemini API Key** (`AIza...`) to activate cloud intelligence and function calling.
