import 'package:flutter/material.dart';
import '../../core/theme/jarvis_theme.dart';
import '../../models/hermes_skill.dart';
import '../../services/skills_service.dart';

class SkillsManagerScreen extends StatefulWidget {
  final SkillsService skillsService;

  const SkillsManagerScreen({super.key, required this.skillsService});

  @override
  State<SkillsManagerScreen> createState() => _SkillsManagerScreenState();
}

class _SkillsManagerScreenState extends State<SkillsManagerScreen> {
  @override
  void initState() {
    super.initState();
    widget.skillsService.addListener(_onSkillsUpdated);
  }

  @override
  void dispose() {
    widget.skillsService.removeListener(_onSkillsUpdated);
    super.dispose();
  }

  void _onSkillsUpdated() {
    if (mounted) setState(() {});
  }

  void _showAddSkillDialog([HermesSkill? editingSkill]) {
    final nameCtrl = TextEditingController(text: editingSkill?.name ?? '');
    final descCtrl = TextEditingController(text: editingSkill?.description ?? '');
    final triggersCtrl = TextEditingController(text: editingSkill?.triggers.join(', ') ?? '');
    final urlCtrl = TextEditingController(text: editingSkill?.targetUrl ?? '');
    final speechCtrl = TextEditingController(text: editingSkill?.responseSpeech ?? '');
    SkillActionType actionType = editingSkill?.actionType ?? SkillActionType.customResponse;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            backgroundColor: JarvisTheme.surfaceDark,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: const BorderSide(color: JarvisTheme.arcCyan, width: 1.2),
            ),
            title: Row(
              children: [
                const Icon(Icons.extension, color: JarvisTheme.arcCyan),
                const SizedBox(width: 8),
                Text(
                  editingSkill == null ? "NEW HERMES PROTOCOL" : "EDIT PROTOCOL",
                  style: const TextStyle(color: JarvisTheme.arcCyan, fontSize: 15, letterSpacing: 1.2),
                ),
              ],
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _fieldLabel("Protocol Name:"),
                  _inputField(nameCtrl, "e.g. Smart Fan / Discord Ping"),
                  const SizedBox(height: 12),
                  _fieldLabel("Trigger Phrases (comma separated):"),
                  _inputField(triggersCtrl, "e.g. fan on, room fan, pankha chalao"),
                  const SizedBox(height: 12),
                  _fieldLabel("Action Protocol:"),
                  DropdownButtonFormField<SkillActionType>(
                    value: actionType,
                    dropdownColor: JarvisTheme.surfaceDark,
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                    decoration: _inputDecoration("Action Type"),
                    items: const [
                      DropdownMenuItem(
                        value: SkillActionType.customResponse,
                        child: Text("Voice Response Only"),
                      ),
                      DropdownMenuItem(
                        value: SkillActionType.webhook,
                        child: Text("HTTP Webhook (IoT / Home Assistant)"),
                      ),
                      DropdownMenuItem(
                        value: SkillActionType.urlScheme,
                        child: Text("App / URL Scheme"),
                      ),
                    ],
                    onChanged: (val) {
                      if (val != null) setDialogState(() => actionType = val);
                    },
                  ),
                  if (actionType == SkillActionType.webhook || actionType == SkillActionType.urlScheme) ...[
                    const SizedBox(height: 12),
                    _fieldLabel(actionType == SkillActionType.webhook ? "Webhook URL (GET/POST):" : "URL / Deep Link:"),
                    _inputField(urlCtrl, "http://192.168.1.100:8123/api/webhook/..."),
                  ],
                  const SizedBox(height: 12),
                  _fieldLabel("Voice Speech Response:"),
                  _inputField(speechCtrl, "e.g. Fan activated at full speed, Boss."),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("CANCEL", style: TextStyle(color: Colors.grey)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: JarvisTheme.arcCyan,
                  foregroundColor: Colors.black,
                ),
                onPressed: () {
                  final name = nameCtrl.text.trim();
                  final triggers = triggersCtrl.text
                      .split(',')
                      .map((t) => t.trim())
                      .where((t) => t.isNotEmpty)
                      .toList();

                  if (name.isEmpty || triggers.isEmpty) return;

                  final skill = HermesSkill(
                    id: editingSkill?.id ?? 'skill_${DateTime.now().millisecondsSinceEpoch}',
                    name: name,
                    description: descCtrl.text.trim(),
                    triggers: triggers,
                    actionType: actionType,
                    targetUrl: urlCtrl.text.trim().isNotEmpty ? urlCtrl.text.trim() : null,
                    responseSpeech: speechCtrl.text.trim().isNotEmpty
                        ? speechCtrl.text.trim()
                        : "Protocol $name executed.",
                    isEnabled: editingSkill?.isEnabled ?? true,
                  );

                  if (editingSkill == null) {
                    widget.skillsService.addSkill(skill);
                  } else {
                    widget.skillsService.updateSkill(skill);
                  }
                  Navigator.pop(context);
                },
                child: Text(editingSkill == null ? "INITIALIZE" : "UPDATE"),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _fieldLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(text, style: const TextStyle(color: JarvisTheme.textSecondary, fontSize: 11)),
    );
  }

  Widget _inputField(TextEditingController ctrl, String hint) {
    return TextField(
      controller: ctrl,
      style: const TextStyle(color: Colors.white, fontSize: 13),
      decoration: _inputDecoration(hint),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: Colors.white.withValues(alpha: 0.3), fontSize: 12),
      filled: true,
      fillColor: Colors.black38,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: JarvisTheme.arcBlue),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: JarvisTheme.arcCyan),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final skills = widget.skillsService.skills;

    return Scaffold(
      backgroundColor: JarvisTheme.background,
      appBar: AppBar(
        title: const Text(
          "HERMES SKILL PROTOCOLS",
          style: TextStyle(
            color: JarvisTheme.arcCyan,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle_outline, color: JarvisTheme.arcCyan),
            onPressed: () => _showAddSkillDialog(),
          ),
        ],
      ),
      body: skills.isEmpty
          ? const Center(
              child: Text(
                "NO CUSTOM PROTOCOLS FOUND\nTAP + TO INITIALIZE ONE",
                textAlign: TextAlign.center,
                style: TextStyle(color: JarvisTheme.textSecondary, letterSpacing: 1.2),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: skills.length,
              itemBuilder: (context, index) {
                final skill = skills[index];
                return _buildSkillCard(skill);
              },
            ),
    );
  }

  Widget _buildSkillCard(HermesSkill skill) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: JarvisTheme.surfaceDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: skill.isEnabled ? JarvisTheme.arcCyan.withValues(alpha: 0.5) : Colors.grey.withValues(alpha: 0.2),
          width: 1.2,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  skill.name.toUpperCase(),
                  style: TextStyle(
                    color: skill.isEnabled ? JarvisTheme.textPrimary : Colors.grey,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.1,
                  ),
                ),
              ),
              Switch(
                value: skill.isEnabled,
                activeColor: JarvisTheme.arcCyan,
                onChanged: (_) => widget.skillsService.toggleSkill(skill.id),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            "Action: ${skill.actionType.name.toUpperCase()}${skill.targetUrl != null ? ' (${skill.targetUrl})' : ''}",
            style: const TextStyle(color: JarvisTheme.textSecondary, fontSize: 11),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: skill.triggers.map((trig) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: JarvisTheme.arcCyan.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: JarvisTheme.glassBorder),
                ),
                child: Text(
                  "\"$trig\"",
                  style: const TextStyle(color: JarvisTheme.arcCyan, fontSize: 10),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton.icon(
                icon: const Icon(Icons.edit, size: 14, color: JarvisTheme.arcBlue),
                label: const Text("EDIT", style: TextStyle(color: JarvisTheme.arcBlue, fontSize: 11)),
                onPressed: () => _showAddSkillDialog(skill),
              ),
              TextButton.icon(
                icon: const Icon(Icons.delete_outline, size: 14, color: Colors.redAccent),
                label: const Text("DELETE", style: TextStyle(color: Colors.redAccent, fontSize: 11)),
                onPressed: () => widget.skillsService.deleteSkill(skill.id),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
