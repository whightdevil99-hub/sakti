import 'package:flutter/material.dart';
import '../../core/theme/jarvis_theme.dart';
import '../../models/assistant_response.dart';
import '../../services/hybrid_router.dart';
import '../../services/local_actions_service.dart';
import '../../services/gemini_service.dart';
import '../../services/memory_service.dart';
import '../../services/skills_service.dart';
import '../../services/stt_service.dart';
import '../../services/tts_service.dart';
import '../../services/wake_word_service.dart';
import '../widgets/glowing_orb.dart';
import '../widgets/live_waveform.dart';
import 'neural_memory_screen.dart';
import 'skills_manager_screen.dart';

class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});

  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen> {
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  // Core Services
  late LocalActionsService _localActions;
  late HybridRouter _router;
  final SkillsService _skillsService = SkillsService();
  final MemoryService _memoryService = MemoryService();
  GeminiService? _geminiService;
  final TtsService _ttsService = TtsService();
  final SttService _sttService = SttService();
  final WakeWordService _wakeWordService = WakeWordService();

  // State
  AssistantState _assistantState = AssistantState.idle;
  String _lastUserQuery = "";
  String _assistantSpokenText = "Online and awaiting your command, Boss.";
  String? _lastExecutedAction;

  // Configurations
  String _geminiApiKey = "";
  String _picovoiceAccessKey = "";
  bool _isWakeWordActive = false;

  @override
  void initState() {
    super.initState();
    _localActions = LocalActionsService();
    _router = HybridRouter(
      localActions: _localActions,
      skillsService: _skillsService,
      memoryService: _memoryService,
    );
    _initVoiceServices();
  }

  Future<void> _initVoiceServices() async {
    await _ttsService.init(
      onStart: () {
        if (mounted) {
          setState(() => _assistantState = AssistantState.speaking);
        }
      },
      onComplete: () {
        if (mounted) {
          setState(() {
            _assistantState = _isWakeWordActive ? AssistantState.idle : AssistantState.idle;
          });
        }
      },
    );
    await _sttService.init();
  }

  void _configureSettings({required String geminiKey, required String picovoiceKey}) {
    setState(() {
      _geminiApiKey = geminiKey.trim();
      _picovoiceAccessKey = picovoiceKey.trim();

      if (_geminiApiKey.isNotEmpty) {
        _geminiService = GeminiService(
          apiKey: _geminiApiKey,
          localActions: _localActions,
          memoryService: _memoryService,
        );
        _router = HybridRouter(
          localActions: _localActions,
          geminiService: _geminiService,
          skillsService: _skillsService,
          memoryService: _memoryService,
        );
      }
    });

    if (_picovoiceAccessKey.isNotEmpty) {
      _toggleWakeWord(enable: true);
    }
  }

  Future<void> _toggleWakeWord({bool? enable}) async {
    final shouldEnable = enable ?? !_isWakeWordActive;

    if (shouldEnable) {
      if (_picovoiceAccessKey.isEmpty) {
        _showSettingsDialog();
        return;
      }

      final success = await _wakeWordService.startListening(
        accessKey: _picovoiceAccessKey,
        onWakeWordDetected: () {
          // Wake word triggered! Automatically start speech recognition
          _startVoiceListening();
        },
        onError: (err) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(err), backgroundColor: Colors.redAccent),
          );
        },
      );

      setState(() => _isWakeWordActive = success);
    } else {
      await _wakeWordService.stopListening();
      setState(() => _isWakeWordActive = false);
    }
  }

  Future<void> _startVoiceListening() async {
    // If TTS is currently speaking, stop it
    await _ttsService.stop();

    setState(() {
      _assistantState = AssistantState.listening;
    });

    await _sttService.startListening(
      onResult: (words, isFinal) {
        setState(() {
          _lastUserQuery = words;
        });

        if (isFinal && words.trim().isNotEmpty) {
          _handleUserCommand(words);
        }
      },
    );
  }

  Future<void> _stopVoiceListening() async {
    await _sttService.stopListening();
    if (_assistantState == AssistantState.listening) {
      setState(() => _assistantState = AssistantState.idle);
    }
  }

  Future<void> _handleUserCommand(String input) async {
    final query = input.trim();
    if (query.isEmpty) return;

    await _stopVoiceListening();
    _textController.clear();
    FocusScope.of(context).unfocus();

    setState(() {
      _lastUserQuery = query;
      _assistantState = AssistantState.thinking;
      _lastExecutedAction = null;
    });

    final response = await _router.processQuery(query);

    setState(() {
      _assistantSpokenText = response.speechText;
      _lastExecutedAction = response.actionName;
      _assistantState = AssistantState.speaking;
    });

    // Voice Output via TTS
    await _ttsService.speak(response.speechText);
  }

  void _onOrbTap() {
    if (_assistantState == AssistantState.listening) {
      _stopVoiceListening();
    } else if (_assistantState == AssistantState.speaking) {
      _ttsService.stop();
      setState(() => _assistantState = AssistantState.idle);
    } else {
      _startVoiceListening();
    }
  }

  void _showSettingsDialog() {
    final geminiCtrl = TextEditingController(text: _geminiApiKey);
    final picovoiceCtrl = TextEditingController(text: _picovoiceAccessKey);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: JarvisTheme.surfaceDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: JarvisTheme.arcCyan, width: 1.2),
        ),
        title: const Row(
          children: [
            Icon(Icons.memory, color: JarvisTheme.arcCyan),
            SizedBox(width: 8),
            Text("SAKTI NEURAL CONFIG", style: TextStyle(color: JarvisTheme.arcCyan, fontSize: 16)),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Gemini API Key (Cloud Brain & Tools):",
                style: TextStyle(color: JarvisTheme.textSecondary, fontSize: 12),
              ),
              const SizedBox(height: 6),
              TextField(
                controller: geminiCtrl,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: _dialogInputDecoration("AIzaSy..."),
              ),
              const SizedBox(height: 16),
              const Text(
                "Picovoice Access Key (Wake Word 'Hey Sakti'):",
                style: TextStyle(color: JarvisTheme.textSecondary, fontSize: 12),
              ),
              const SizedBox(height: 6),
              TextField(
                controller: picovoiceCtrl,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: _dialogInputDecoration("AccessKey from console.picovoice.ai"),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("CANCEL", style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: JarvisTheme.arcCyan,
              foregroundColor: Colors.black,
            ),
            onPressed: () {
              _configureSettings(
                geminiKey: geminiCtrl.text,
                picovoiceKey: picovoiceCtrl.text,
              );
              Navigator.pop(context);
            },
            child: const Text("ACTIVATE PROTOCOLS"),
          ),
        ],
      ),
    );
  }

  InputDecoration _dialogInputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: Colors.white.withValues(alpha: 0.3)),
      filled: true,
      fillColor: Colors.black26,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: JarvisTheme.arcBlue),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: JarvisTheme.arcCyan),
      ),
    );
  }

  @override
  void dispose() {
    _ttsService.stop();
    _sttService.stopListening();
    _wakeWordService.stopListening();
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _buildHudHeader(),
            Expanded(
              child: SingleChildScrollView(
                controller: _scrollController,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    children: [
                      const SizedBox(height: 16),
                      GlowingOrb(
                        state: _assistantState,
                        size: 240,
                        onTap: _onOrbTap,
                      ),
                      const SizedBox(height: 20),
                      _buildStateLabel(),
                      const SizedBox(height: 16),
                      LiveWaveform(state: _assistantState),
                      const SizedBox(height: 24),
                      _buildHologramCard(),
                      const SizedBox(height: 20),
                      _buildQuickActionDeck(),
                    ],
                  ),
                ),
              ),
            ),
            _buildBottomControlDeck(),
          ],
        ),
      ),
    );
  }

  Widget _buildHudHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color: JarvisTheme.surfaceDark.withValues(alpha: 0.6),
        border: const Border(
          bottom: BorderSide(color: JarvisTheme.glassBorder, width: 1),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: JarvisTheme.arcCyan,
                  boxShadow: [
                    BoxShadow(color: JarvisTheme.arcCyan, blurRadius: 8, spreadRadius: 2),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "S.A.K.T.I.",
                    style: TextStyle(
                      color: JarvisTheme.textPrimary,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2.0,
                    ),
                  ),
                  Text(
                    "HYBRID AI PROTOCOL",
                    style: TextStyle(
                      color: JarvisTheme.textSecondary,
                      fontSize: 10,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ],
          ),
          Row(
            children: [
              // Hermes Skills / Protocols Manager
              IconButton(
                tooltip: "Hermes Skill Protocols",
                icon: const Icon(Icons.extension_outlined, color: JarvisTheme.arcCyan),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SkillsManagerScreen(skillsService: _skillsService),
                    ),
                  );
                },
              ),
              // Neural Memory Vault (Self-Improving Core)
              IconButton(
                tooltip: "Neural Memory Vault",
                icon: const Icon(Icons.psychology_outlined, color: JarvisTheme.arcCyan),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => NeuralMemoryScreen(memoryService: _memoryService),
                    ),
                  );
                },
              ),
              // Wake Word Listening Toggle Indicator
              IconButton(
                tooltip: _isWakeWordActive ? "Wake Word Active" : "Wake Word Inactive",
                icon: Icon(
                  Icons.hearing,
                  color: _isWakeWordActive ? JarvisTheme.arcCyan : Colors.grey,
                ),
                onPressed: () => _toggleWakeWord(),
              ),
              IconButton(
                icon: const Icon(Icons.settings_suggest_outlined, color: JarvisTheme.arcCyan),
                onPressed: _showSettingsDialog,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStateLabel() {
    String label;
    Color color;

    switch (_assistantState) {
      case AssistantState.idle:
        label = _isWakeWordActive
            ? "WAKE WORD ACTIVE • SAY 'JARVIS' / 'HEY SAKTI'"
            : "SYSTEM IDLE • TAP OR TRANSMIT COMMAND";
        color = JarvisTheme.arcCyan;
        break;
      case AssistantState.listening:
        label = "LISTENING TO BOSS...";
        color = JarvisTheme.listeningCyan;
        break;
      case AssistantState.thinking:
        label = "NEURAL PROCESSING IN PROGRESS...";
        color = JarvisTheme.thinkingPurple;
        break;
      case AssistantState.speaking:
        label = "SAKTI TRANSMITTING AUDIO...";
        color = JarvisTheme.speakingGreen;
        break;
    }

    return Text(
      label,
      style: TextStyle(
        color: color,
        fontSize: 11,
        letterSpacing: 1.5,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildHologramCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: JarvisTheme.surfaceDark.withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: JarvisTheme.glassBorder, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: JarvisTheme.arcCyan.withValues(alpha: 0.08),
            blurRadius: 16,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_lastUserQuery.isNotEmpty) ...[
            Row(
              children: [
                const Icon(Icons.person_pin, size: 14, color: JarvisTheme.textSecondary),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    "BOSS: $_lastUserQuery",
                    style: const TextStyle(
                      color: JarvisTheme.textSecondary,
                      fontSize: 12,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              ],
            ),
            const Divider(color: JarvisTheme.glassBorder, height: 16),
          ],
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.smart_toy_outlined, size: 16, color: JarvisTheme.arcCyan),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  _assistantSpokenText,
                  style: const TextStyle(
                    color: JarvisTheme.textPrimary,
                    fontSize: 14,
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ),
          if (_lastExecutedAction != null) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: JarvisTheme.arcCyan.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: JarvisTheme.arcCyan.withValues(alpha: 0.4)),
              ),
              child: Text(
                "ACTION EXECUTED: ${_lastExecutedAction!.toUpperCase()}",
                style: const TextStyle(
                  color: JarvisTheme.arcCyan,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildQuickActionDeck() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: [
        _buildActionChip(
          icon: Icons.flashlight_on,
          label: "Torch ON",
          onTap: () => _handleUserCommand("torch on"),
        ),
        _buildActionChip(
          icon: Icons.flashlight_off,
          label: "Torch OFF",
          onTap: () => _handleUserCommand("torch off"),
        ),
        _buildActionChip(
          icon: Icons.battery_charging_full,
          label: "Battery",
          onTap: () => _handleUserCommand("battery status"),
        ),
        _buildActionChip(
          icon: Icons.access_time,
          label: "Time",
          onTap: () => _handleUserCommand("current time"),
        ),
        _buildActionChip(
          icon: Icons.ondemand_video,
          label: "YouTube",
          onTap: () => _handleUserCommand("open youtube"),
        ),
      ],
    );
  }

  Widget _buildActionChip({required IconData icon, required String label, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: JarvisTheme.surfaceDark,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: JarvisTheme.glassBorder),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: JarvisTheme.arcCyan),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(color: JarvisTheme.textPrimary, fontSize: 11)),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomControlDeck() {
    final isListening = _assistantState == AssistantState.listening;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: JarvisTheme.surfaceDark,
        border: const Border(top: BorderSide(color: JarvisTheme.glassBorder)),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _textController,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: isListening ? "Listening to your voice..." : "Transmit command to SAKTI...",
                hintStyle: TextStyle(color: Colors.white.withValues(alpha: 0.3)),
                filled: true,
                fillColor: Colors.black45,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: const BorderSide(color: JarvisTheme.glassBorder),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: const BorderSide(color: JarvisTheme.glassBorder),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: const BorderSide(color: JarvisTheme.arcCyan),
                ),
              ),
              onSubmitted: _handleUserCommand,
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            icon: const Icon(Icons.send_rounded, color: JarvisTheme.arcCyan),
            onPressed: () => _handleUserCommand(_textController.text),
          ),
          IconButton(
            icon: Icon(
              isListening ? Icons.mic : Icons.mic_none,
              color: isListening ? JarvisTheme.listeningCyan : JarvisTheme.arcBlue,
            ),
            onPressed: _onOrbTap,
          ),
        ],
      ),
    );
  }
}
