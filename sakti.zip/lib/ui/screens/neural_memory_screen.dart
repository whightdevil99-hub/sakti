import 'package:flutter/material.dart';
import '../../core/theme/jarvis_theme.dart';
import '../../models/memory_item.dart';
import '../../services/memory_service.dart';

class NeuralMemoryScreen extends StatefulWidget {
  final MemoryService memoryService;

  const NeuralMemoryScreen({super.key, required this.memoryService});

  @override
  State<NeuralMemoryScreen> createState() => _NeuralMemoryScreenState();
}

class _NeuralMemoryScreenState extends State<NeuralMemoryScreen> {
  MemoryType? _selectedFilter;

  @override
  void initState() {
    super.initState();
    widget.memoryService.addListener(_onUpdated);
  }

  @override
  void dispose() {
    widget.memoryService.removeListener(_onUpdated);
    super.dispose();
  }

  void _onUpdated() {
    if (mounted) setState(() {});
  }

  void _showAddMemoryDialog() {
    final textCtrl = TextEditingController();
    MemoryType chosenType = MemoryType.fact;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: JarvisTheme.surfaceDark,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: JarvisTheme.arcCyan, width: 1.2),
          ),
          title: const Row(
            children: [
              Icon(Icons.psychology, color: JarvisTheme.arcCyan),
              SizedBox(width: 8),
              Text(
                "SYNAPSE ENCODING",
                style: TextStyle(color: JarvisTheme.arcCyan, fontSize: 15, letterSpacing: 1.2),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Encode a new fact or rule into SAKTI's neural memory bank:",
                style: TextStyle(color: JarvisTheme.textSecondary, fontSize: 12),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<MemoryType>(
                value: chosenType,
                dropdownColor: JarvisTheme.surfaceDark,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: InputDecoration(
                  labelText: "Memory Type",
                  labelStyle: const TextStyle(color: JarvisTheme.arcCyan),
                  filled: true,
                  fillColor: Colors.black38,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                ),
                items: const [
                  DropdownMenuItem(value: MemoryType.fact, child: Text("Boss Fact")),
                  DropdownMenuItem(value: MemoryType.preference, child: Text("Preference / Habit")),
                  DropdownMenuItem(value: MemoryType.correction, child: Text("Behavioral Correction")),
                ],
                onChanged: (val) {
                  if (val != null) setDialogState(() => chosenType = val);
                },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: textCtrl,
                maxLines: 3,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: InputDecoration(
                  hintText: "e.g. Boss works on Flutter apps and prefers dark mode.",
                  hintStyle: TextStyle(color: Colors.white.withValues(alpha: 0.3), fontSize: 12),
                  filled: true,
                  fillColor: Colors.black38,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: JarvisTheme.arcBlue),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("CANCEL", style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: JarvisTheme.arcCyan,
                foregroundColor: Colors.black,
              ),
              onPressed: () {
                final content = textCtrl.text.trim();
                if (content.isNotEmpty) {
                  widget.memoryService.rememberFact(content, type: chosenType);
                }
                Navigator.pop(context);
              },
              child: const Text("COMMIT TO MEMORY"),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final allMemories = widget.memoryService.memories;
    final displayedMemories = _selectedFilter == null
        ? allMemories
        : allMemories.where((m) => m.type == _selectedFilter).toList();

    return Scaffold(
      backgroundColor: JarvisTheme.background,
      appBar: AppBar(
        title: const Text(
          "NEURAL MEMORY VAULT",
          style: TextStyle(
            color: JarvisTheme.arcCyan,
            fontSize: 15,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
        ),
        actions: [
          IconButton(
            tooltip: "Add Synapse Memory",
            icon: const Icon(Icons.add_circle_outline, color: JarvisTheme.arcCyan),
            onPressed: _showAddMemoryDialog,
          ),
          IconButton(
            tooltip: "Purge All Memories",
            icon: const Icon(Icons.delete_sweep_outlined, color: Colors.redAccent),
            onPressed: () {
              widget.memoryService.clearAllMemories();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Telemetry Stats Bar
          _buildStatsBar(allMemories.length),

          // Filter Chips
          _buildFilterRow(),

          // Memory Items List
          Expanded(
            child: displayedMemories.isEmpty
                ? const Center(
                    child: Text(
                      "NO MEMORIES ENCODED YET\nSAKTI WILL AUTONOMOUSLY LEARN FROM CHAT",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: JarvisTheme.textSecondary, letterSpacing: 1.2, height: 1.5),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: displayedMemories.length,
                    itemBuilder: (context, index) {
                      return _buildMemoryCard(displayedMemories[index]);
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsBar(int count) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: JarvisTheme.surfaceDark,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: JarvisTheme.glassBorder),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _statItem("ACTIVE SYNAPSES", "$count"),
          Container(width: 1, height: 28, color: JarvisTheme.glassBorder),
          _statItem("LEARNING CORE", "ONLINE"),
          Container(width: 1, height: 28, color: JarvisTheme.glassBorder),
          _statItem("ADAPTATION", "AUTO"),
        ],
      ),
    );
  }

  Widget _statItem(String title, String value) {
    return Column(
      children: [
        Text(value, style: const TextStyle(color: JarvisTheme.arcCyan, fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 2),
        Text(title, style: const TextStyle(color: JarvisTheme.textSecondary, fontSize: 9, letterSpacing: 1.1)),
      ],
    );
  }

  Widget _buildFilterRow() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        children: [
          _filterChip("All", null),
          const SizedBox(width: 8),
          _filterChip("Facts", MemoryType.fact),
          const SizedBox(width: 8),
          _filterChip("Preferences", MemoryType.preference),
          const SizedBox(width: 8),
          _filterChip("Corrections", MemoryType.correction),
        ],
      ),
    );
  }

  Widget _filterChip(String label, MemoryType? type) {
    final isSelected = _selectedFilter == type;
    return ChoiceChip(
      label: Text(label),
      selected: isSelected,
      selectedColor: JarvisTheme.arcCyan.withValues(alpha: 0.25),
      backgroundColor: JarvisTheme.surfaceDark,
      labelStyle: TextStyle(
        color: isSelected ? JarvisTheme.arcCyan : JarvisTheme.textSecondary,
        fontSize: 11,
      ),
      side: BorderSide(
        color: isSelected ? JarvisTheme.arcCyan : JarvisTheme.glassBorder,
      ),
      onSelected: (_) {
        setState(() => _selectedFilter = type);
      },
    );
  }

  Widget _buildMemoryCard(MemoryItem memory) {
    Color typeColor = JarvisTheme.arcCyan;
    if (memory.type == MemoryType.correction) typeColor = JarvisTheme.thinkingPurple;
    if (memory.type == MemoryType.preference) typeColor = JarvisTheme.speakingGreen;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: JarvisTheme.surfaceDark,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: typeColor.withValues(alpha: 0.4), width: 1.1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: typeColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  memory.type.name.toUpperCase(),
                  style: TextStyle(color: typeColor, fontSize: 9, fontWeight: FontWeight.bold),
                ),
              ),
              Row(
                children: [
                  Text(
                    "CONFIDENCE: ${memory.confidenceScore}x",
                    style: const TextStyle(color: JarvisTheme.textSecondary, fontSize: 10),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.close, size: 14, color: Colors.grey),
                    onPressed: () => widget.memoryService.deleteMemory(memory.id),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            memory.content,
            style: const TextStyle(color: JarvisTheme.textPrimary, fontSize: 13, height: 1.4),
          ),
        ],
      ),
    );
  }
}
