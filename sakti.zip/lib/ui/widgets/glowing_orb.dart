import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/theme/jarvis_theme.dart';

enum AssistantState {
  idle,
  listening,
  thinking,
  speaking,
}

class GlowingOrb extends StatefulWidget {
  final AssistantState state;
  final double size;
  final VoidCallback? onTap;

  const GlowingOrb({
    super.key,
    required this.state,
    this.size = 220,
    this.onTap,
  });

  @override
  State<GlowingOrb> createState() => _GlowingOrbState();
}

class _GlowingOrbState extends State<GlowingOrb> with TickerProviderStateMixin {
  late AnimationController _rotationController;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();

    _rotationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.92, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void didUpdateWidget(covariant GlowingOrb oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.state != widget.state) {
      _updateAnimationSpeed();
    }
  }

  void _updateAnimationSpeed() {
    switch (widget.state) {
      case AssistantState.idle:
        _rotationController.duration = const Duration(seconds: 12);
        _pulseController.duration = const Duration(milliseconds: 1800);
        break;
      case AssistantState.listening:
        _rotationController.duration = const Duration(seconds: 4);
        _pulseController.duration = const Duration(milliseconds: 800);
        break;
      case AssistantState.thinking:
        _rotationController.duration = const Duration(seconds: 2);
        _pulseController.duration = const Duration(milliseconds: 600);
        break;
      case AssistantState.speaking:
        _rotationController.duration = const Duration(seconds: 5);
        _pulseController.duration = const Duration(milliseconds: 700);
        break;
    }
    if (_rotationController.isAnimating) _rotationController.repeat();
    if (_pulseController.isAnimating) _pulseController.repeat(reverse: true);
  }

  Color _getCoreColor() {
    switch (widget.state) {
      case AssistantState.idle:
        return JarvisTheme.arcCyan;
      case AssistantState.listening:
        return JarvisTheme.listeningCyan;
      case AssistantState.thinking:
        return JarvisTheme.thinkingPurple;
      case AssistantState.speaking:
        return JarvisTheme.speakingGreen;
    }
  }

  @override
  void dispose() {
    _rotationController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final activeColor = _getCoreColor();

    return GestureDetector(
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: Listenable.merge([_rotationController, _pulseController]),
        builder: (context, child) {
          return SizedBox(
            width: widget.size,
            height: widget.size,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Outer HUD Rings Painter
                CustomPaint(
                  size: Size(widget.size, widget.size),
                  painter: _HudRingPainter(
                    angle: _rotationController.value * 2 * math.pi,
                    color: activeColor,
                  ),
                ),

                // Pulsating Glowing Core
                Transform.scale(
                  scale: _pulseAnimation.value,
                  child: Container(
                    width: widget.size * 0.48,
                    height: widget.size * 0.48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          JarvisTheme.neonCore,
                          activeColor.withValues(alpha: 0.8),
                          activeColor.withValues(alpha: 0.2),
                          Colors.transparent,
                        ],
                        stops: const [0.1, 0.45, 0.8, 1.0],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: activeColor.withValues(alpha: 0.5),
                          blurRadius: 35,
                          spreadRadius: 8,
                        ),
                        BoxShadow(
                          color: activeColor.withValues(alpha: 0.3),
                          blurRadius: 60,
                          spreadRadius: 15,
                        ),
                      ],
                    ),
                    child: Center(
                      child: Container(
                        width: widget.size * 0.16,
                        height: widget.size * 0.16,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.white,
                              blurRadius: 16,
                              spreadRadius: 3,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _HudRingPainter extends CustomPainter {
  final double angle;
  final Color color;

  _HudRingPainter({required this.angle, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paintArc = Paint()
      ..color = color.withValues(alpha: 0.6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    final paintDashed = Paint()
      ..color = color.withValues(alpha: 0.3)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    // Outer subtle circle
    canvas.drawCircle(center, radius - 4, paintDashed);

    // Rotating segment arcs (Clockwise)
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(angle);
    canvas.translate(-center.dx, -center.dy);

    final rectOuter = Rect.fromCircle(center: center, radius: radius - 10);
    canvas.drawArc(rectOuter, 0, math.pi / 2.5, false, paintArc);
    canvas.drawArc(rectOuter, math.pi, math.pi / 2.5, false, paintArc);

    canvas.restore();

    // Counter-Rotating inner segmented arcs
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(-angle * 1.5);
    canvas.translate(-center.dx, -center.dy);

    final rectInner = Rect.fromCircle(center: center, radius: radius - 26);
    final paintInnerArc = Paint()
      ..color = color.withValues(alpha: 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0;

    canvas.drawArc(rectInner, math.pi / 4, math.pi / 3, false, paintInnerArc);
    canvas.drawArc(rectInner, math.pi * 1.25, math.pi / 3, false, paintInnerArc);

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _HudRingPainter oldDelegate) {
    return oldDelegate.angle != angle || oldDelegate.color != color;
  }
}
