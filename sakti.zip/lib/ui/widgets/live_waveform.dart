import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/theme/jarvis_theme.dart';
import 'glowing_orb.dart';

class LiveWaveform extends StatefulWidget {
  final AssistantState state;
  final double height;
  final int barCount;

  const LiveWaveform({
    super.key,
    required this.state,
    this.height = 48,
    this.barCount = 28,
  });

  @override
  State<LiveWaveform> createState() => _LiveWaveformState();
}

class _LiveWaveformState extends State<LiveWaveform> with SingleTickerProviderStateMixin {
  late AnimationController _animController;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isActive = widget.state == AssistantState.listening || widget.state == AssistantState.speaking;
    final isThinking = widget.state == AssistantState.thinking;

    return AnimatedBuilder(
      animation: _animController,
      builder: (context, child) {
        return SizedBox(
          height: widget.height,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: List.generate(widget.barCount, (index) {
              final phase = (index / widget.barCount) * 2 * math.pi;
              double factor = 0.15;

              if (isActive) {
                factor = 0.25 + 0.75 * math.sin(_animController.value * 2 * math.pi + phase).abs();
              } else if (isThinking) {
                factor = 0.2 + 0.4 * math.sin(_animController.value * 4 * math.pi + phase).abs();
              }

              final barHeight = math.max(4.0, widget.height * factor);

              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 2.0),
                width: 3.5,
                height: barHeight,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(2.0),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      JarvisTheme.arcCyan,
                      JarvisTheme.arcBlue.withValues(alpha: 0.7),
                    ],
                  ),
                  boxShadow: isActive
                      ? [
                          BoxShadow(
                            color: JarvisTheme.arcCyan.withValues(alpha: 0.6),
                            blurRadius: 4,
                            spreadRadius: 1,
                          )
                        ]
                      : null,
                ),
              );
            }),
          ),
        );
      },
    );
  }
}
