import 'package:flutter/material.dart';

class JarvisTheme {
  // Sci-Fi Dark Backgrounds
  static const Color background = Color(0xFF060A13);
  static const Color surfaceDark = Color(0xFF0D1424);
  static const Color glassBorder = Color(0x3300F2FE);

  // Futuristic Holographic Blues & Cyans
  static const Color arcCyan = Color(0xFF00F2FE);
  static const Color arcBlue = Color(0xFF4FACFE);
  static const Color neonCore = Color(0xFFE0FFFF);

  // Accent & State Colors
  static const Color listeningCyan = Color(0xFF00E5FF);
  static const Color thinkingPurple = Color(0xFFB388FF);
  static const Color speakingGreen = Color(0xFF00E676);
  static const Color warningOrange = Color(0xFFFF9100);

  // Text Colors
  static const Color textPrimary = Color(0xFFEAFBFF);
  static const Color textSecondary = Color(0xFF7B99B8);
  static const Color textAccent = Color(0xFF00F2FE);

  static ThemeData get darkTheme {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: background,
      primaryColor: arcCyan,
      fontFamily: 'monospace',
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
      ),
      colorScheme: const ColorScheme.dark(
        primary: arcCyan,
        secondary: arcBlue,
        surface: surfaceDark,
      ),
    );
  }
}
