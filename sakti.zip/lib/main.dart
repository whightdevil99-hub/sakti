import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core/theme/jarvis_theme.dart';
import 'ui/screens/assistant_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // Set immersive dark UI overlay for Jarvis aesthetics
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: JarvisTheme.background,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  runApp(const SaktiApp());
}

class SaktiApp extends StatelessWidget {
  const SaktiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SAKTI AI Assistant',
      debugShowCheckedModeBanner: false,
      theme: JarvisTheme.darkTheme,
      home: const AssistantScreen(),
    );
  }
}
