import '../models/assistant_response.dart';
import 'gemini_service.dart';
import 'local_actions_service.dart';
import 'memory_service.dart';
import 'skills_service.dart';

class HybridRouter {
  final LocalActionsService localActions;
  final GeminiService? geminiService;
  final SkillsService? skillsService;
  final MemoryService? memoryService;

  HybridRouter({
    required this.localActions,
    this.geminiService,
    this.skillsService,
    this.memoryService,
  });

  /// Processes user voice or text input
  Future<AssistantResponse> processQuery(String rawInput) async {
    final query = rawInput.trim().toLowerCase();

    if (query.isEmpty) {
      return AssistantResponse(
        speechText: "I'm listening, Boss. How can I help?",
        source: ResponseSource.localAction,
      );
    }

    // ==========================================
    // 1. FAST LOCAL OFFLINE INTENT MATCHING
    // ==========================================

    // Flashlight / Torch ON
    if (_matches(query, [
      'torch on',
      'turn on flashlight',
      'turn on torch',
      'flashlight on',
      'torch jalao',
      'batti jalao',
      'light on karo',
    ])) {
      return await localActions.toggleFlashlight(turnOn: true);
    }

    // Flashlight / Torch OFF
    if (_matches(query, [
      'torch off',
      'turn off flashlight',
      'turn off torch',
      'flashlight off',
      'torch band karo',
      'batti band karo',
      'light off karo',
    ])) {
      return await localActions.toggleFlashlight(turnOn: false);
    }

    // Battery Status
    if (_matches(query, [
      'battery',
      'battery percentage',
      'battery status',
      'battery level',
      'charging status',
      'charge kitna hai',
      'battery kitni hai',
    ])) {
      return await localActions.getBatteryStatus();
    }

    // Current Time
    if (_matches(query, [
      'what time',
      'current time',
      'time kya hai',
      'kitne baje',
      'samay kya hua',
      'tell me the time',
    ])) {
      return localActions.getCurrentTime();
    }

    // Current Date
    if (_matches(query, [
      'what date',
      'current date',
      'aaj ki date',
      'aaj kya tareekh hai',
      'today date',
      'tell me the date',
    ])) {
      return localActions.getCurrentDate();
    }

    // Direct Self-Improvement / Memory Teaching Command ("remember that ...", "yaad rakhna ki ...")
    if (memoryService != null && (query.startsWith('remember that ') || query.startsWith('remember ') || query.startsWith('yaad rakhna ki ') || query.startsWith('yaad rakhna '))) {
      final fact = _extractMemoryFact(rawInput);
      if (fact.isNotEmpty) {
        await memoryService!.rememberFact(fact);
        return AssistantResponse(
          speechText: "Learned and committed to neural memory bank, Boss: $fact",
          source: ResponseSource.localAction,
          actionName: 'remember_fact',
        );
      }
    }

    // App Launching ("open youtube", "open whatsapp", "youtube kholo")
    if (query.startsWith('open ') || query.startsWith('launch ') || query.contains('kholo') || query.contains('chalao')) {
      final appName = _extractAppName(query);
      if (appName.isNotEmpty) {
        return await localActions.openApp(appName);
      }
    }

    // ==========================================
    // 2. HERMES CUSTOM USER SKILL MATCHING
    // ==========================================
    if (skillsService != null) {
      final matchedSkill = skillsService!.matchSkill(query);
      if (matchedSkill != null) {
        return await skillsService!.executeSkill(matchedSkill);
      }
    }

    // ==========================================
    // 3. CLOUD INTELLIGENCE (GEMINI LLM + TOOLS)
    // ==========================================
    if (geminiService != null) {
      return await geminiService!.ask(rawInput);
    }

    // Fallback if no cloud key configured
    return AssistantResponse(
      speechText: "I recognized your query, but Cloud Intelligence is not configured yet, Boss.",
      source: ResponseSource.fallback,
      isSuccess: false,
    );
  }

  bool _matches(String text, List<String> patterns) {
    for (final pattern in patterns) {
      if (text.contains(pattern)) return true;
    }
    return false;
  }

  String _extractAppName(String text) {
    var cleaned = text
        .replaceAll('open', '')
        .replaceAll('launch', '')
        .replaceAll('kholo', '')
        .replaceAll('chalao', '')
        .trim();
    return cleaned;
  }

  String _extractMemoryFact(String text) {
    var cleaned = text;
    final prefixes = [
      'remember that ',
      'remember ',
      'yaad rakhna ki ',
      'yaad rakhna ',
      'note that ',
    ];
    for (final p in prefixes) {
      if (cleaned.toLowerCase().startsWith(p)) {
        cleaned = cleaned.substring(p.length).trim();
        break;
      }
    }
    return cleaned;
  }
}
