import 'package:flutter_tts/flutter_tts.dart';

class TtsService {
  final FlutterTts _flutterTts = FlutterTts();
  bool _isInitialized = false;

  Future<void> init({VoidCallback? onStart, VoidCallback? onComplete}) async {
    if (_isInitialized) return;

    await _flutterTts.setLanguage("en-US");
    // Jarvis-like calm, deep, sci-fi cadence
    await _flutterTts.setPitch(0.92);
    await _flutterTts.setSpeechRate(0.50);
    await _flutterTts.setVolume(1.0);

    _flutterTts.setStartHandler(() {
      if (onStart != null) onStart();
    });

    _flutterTts.setCompletionHandler(() {
      if (onComplete != null) onComplete();
    });

    _flutterTts.setErrorHandler((msg) {
      if (onComplete != null) onComplete();
    });

    _isInitialized = true;
  }

  Future<void> speak(String text) async {
    if (text.isEmpty) return;
    await stop();
    await _flutterTts.speak(text);
  }

  Future<void> stop() async {
    await _flutterTts.stop();
  }

  void setCompletionHandler(VoidCallback callback) {
    _flutterTts.setCompletionHandler(callback);
  }

  void setStartHandler(VoidCallback callback) {
    _flutterTts.setStartHandler(callback);
  }

  Future<void> setPitch(double pitch) async {
    await _flutterTts.setPitch(pitch);
  }

  Future<void> setSpeechRate(double rate) async {
    await _flutterTts.setSpeechRate(rate);
  }
}
