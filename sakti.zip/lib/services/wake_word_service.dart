import 'package:porcupine_flutter/porcupine_flutter.dart';
import 'package:porcupine_flutter/porcupine_manager.dart';

class WakeWordService {
  PorcupineManager? _porcupineManager;
  bool _isListening = false;

  bool get isListening => _isListening;

  /// Initializes and starts listening for Wake Word ("Hey Sakti" or Builtin JARVIS)
  Future<bool> startListening({
    required String accessKey,
    String? customKeywordPath,
    required Function() onWakeWordDetected,
    Function(String error)? onError,
  }) async {
    if (accessKey.trim().isEmpty) {
      if (onError != null) {
        onError("Picovoice Access Key is required for Wake Word detection.");
      }
      return false;
    }

    try {
      await stopListening();

      void wakeWordCallback(int keywordIndex) {
        onWakeWordDetected();
      }

      if (customKeywordPath != null && customKeywordPath.isNotEmpty) {
        // Custom "Hey Sakti" .ppn model
        _porcupineManager = await PorcupineManager.fromKeywordPaths(
          accessKey,
          [customKeywordPath],
          wakeWordCallback,
          errorCallback: (PorcupineException error) {
            if (onError != null) onError(error.message ?? 'Unknown Porcupine error');
          },
        );
      } else {
        // Fallback to built-in JARVIS keyword
        _porcupineManager = await PorcupineManager.fromBuiltInKeywords(
          accessKey,
          [BuiltInKeyword.JARVIS],
          wakeWordCallback,
          errorCallback: (PorcupineException error) {
            if (onError != null) onError(error.message ?? 'Unknown Porcupine error');
          },
        );
      }

      await _porcupineManager!.start();
      _isListening = true;
      return true;
    } catch (e) {
      _isListening = false;
      if (onError != null) {
        onError("Wake word initialization error: ${e.toString()}");
      }
      return false;
    }
  }

  /// Pauses or stops the background wake word audio listener
  Future<void> stopListening() async {
    if (_porcupineManager != null) {
      await _porcupineManager!.stop();
      await _porcupineManager!.delete();
      _porcupineManager = null;
    }
    _isListening = false;
  }
}
