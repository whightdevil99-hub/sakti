import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/memory_item.dart';

class MemoryService extends ChangeNotifier {
  static const String _storageKey = 'sakti_neural_memory_bank';
  List<MemoryItem> _memories = [];

  List<MemoryItem> get memories => List.unmodifiable(_memories);
  List<MemoryItem> get facts => _memories.where((m) => m.type == MemoryType.fact || m.type == MemoryType.preference).toList();
  List<MemoryItem> get corrections => _memories.where((m) => m.type == MemoryType.correction).toList();
  List<MemoryItem> get learnedSkills => _memories.where((m) => m.type == MemoryType.learnedSkill).toList();

  MemoryService() {
    _loadMemories();
  }

  Future<void> _loadMemories() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw != null && raw.isNotEmpty) {
        final List<dynamic> decoded = jsonDecode(raw);
        _memories = decoded.map((item) => MemoryItem.fromJson(item as Map<String, dynamic>)).toList();
      } else {
        _memories = _getDefaultMemories();
        await _saveMemories();
      }
    } catch (_) {
      _memories = _getDefaultMemories();
    }
    notifyListeners();
  }

  Future<void> _saveMemories() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = jsonEncode(_memories.map((m) => m.toJson()).toList());
      await prefs.setString(_storageKey, raw);
    } catch (_) {}
  }

  /// Adds a new learned fact or preference about Boss
  Future<MemoryItem> rememberFact(String content, {MemoryType type = MemoryType.fact, String? context}) async {
    // Check if duplicate or similar memory exists
    final cleanContent = content.trim();
    final existingIndex = _memories.indexWhere(
      (m) => m.content.toLowerCase() == cleanContent.toLowerCase(),
    );

    if (existingIndex != -1) {
      // Reinforce confidence
      final existing = _memories[existingIndex];
      final updated = existing.copyWith(
        confidenceScore: existing.confidenceScore + 1,
      );
      _memories[existingIndex] = updated;
      await _saveMemories();
      notifyListeners();
      return updated;
    }

    final newMemory = MemoryItem(
      id: 'mem_${DateTime.now().millisecondsSinceEpoch}',
      type: type,
      content: cleanContent,
      context: context,
      createdAt: DateTime.now(),
      confidenceScore: 1,
    );

    _memories.insert(0, newMemory);
    await _saveMemories();
    notifyListeners();
    return newMemory;
  }

  /// Records a behavioral correction when Boss corrects SAKTI
  Future<MemoryItem> recordCorrection({
    required String mistake,
    required String correction,
  }) async {
    final entry = "Correction: When handling '$mistake', prefer '$correction'.";
    return await rememberFact(
      entry,
      type: MemoryType.correction,
      context: "User Correction Feedback",
    );
  }

  Future<void> deleteMemory(String id) async {
    _memories.removeWhere((m) => m.id == id);
    await _saveMemories();
    notifyListeners();
  }

  Future<void> clearAllMemories() async {
    _memories.clear();
    await _saveMemories();
    notifyListeners();
  }

  /// Synthesizes a prompt injection block for Gemini LLM containing learned behaviors & facts
  String buildAdaptivePromptContext() {
    if (_memories.isEmpty) return "";

    final buffer = StringBuffer();
    buffer.writeln("\n[SAKTI SELF-LEARNED ADAPTIVE MEMORY & CORRECTIONS]:");

    if (facts.isNotEmpty) {
      buffer.writeln("- Boss's Profile & Learned Preferences:");
      for (final f in facts.take(8)) {
        buffer.writeln("  * ${f.content}");
      }
    }

    if (corrections.isNotEmpty) {
      buffer.writeln("- Behavioral Corrections & Rules (MUST PRIORITIZE THESE):");
      for (final c in corrections.take(6)) {
        buffer.writeln("  * ${c.content}");
      }
    }

    buffer.writeln("Use these memories to deliver personalized, adaptive, and evolving responses.\n");
    return buffer.toString();
  }

  List<MemoryItem> _getDefaultMemories() {
    return [
      MemoryItem(
        id: 'mem_default_1',
        type: MemoryType.preference,
        content: 'Boss prefers concise, confident, and snappy voice responses.',
        createdAt: DateTime.now(),
        confidenceScore: 5,
      ),
      MemoryItem(
        id: 'mem_default_2',
        type: MemoryType.preference,
        content: 'Assistant name is SAKTI, inspired by Jarvis, Alexa, and Hermes.',
        createdAt: DateTime.now(),
        confidenceScore: 5,
      ),
    ];
  }
}
