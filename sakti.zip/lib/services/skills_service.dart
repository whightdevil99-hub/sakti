import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/assistant_response.dart';
import '../models/hermes_skill.dart';

class SkillsService extends ChangeNotifier {
  static const String _storageKey = 'sakti_hermes_skills';
  List<HermesSkill> _skills = [];

  List<HermesSkill> get skills => List.unmodifiable(_skills);
  List<HermesSkill> get activeSkills => _skills.where((s) => s.isEnabled).toList();

  SkillsService() {
    _loadSkills();
  }

  Future<void> _loadSkills() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final rawData = prefs.getString(_storageKey);

      if (rawData != null && rawData.isNotEmpty) {
        final List<dynamic> decoded = jsonDecode(rawData);
        _skills = decoded.map((item) => HermesSkill.fromJson(item as Map<String, dynamic>)).toList();
      } else {
        _skills = _getDefaultSkills();
        await _saveSkills();
      }
    } catch (e) {
      _skills = _getDefaultSkills();
    }
    notifyListeners();
  }

  Future<void> _saveSkills() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final encoded = jsonEncode(_skills.map((s) => s.toJson()).toList());
      await prefs.setString(_storageKey, encoded);
    } catch (_) {}
  }

  Future<void> addSkill(HermesSkill skill) async {
    _skills.add(skill);
    await _saveSkills();
    notifyListeners();
  }

  Future<void> updateSkill(HermesSkill updated) async {
    final index = _skills.indexWhere((s) => s.id == updated.id);
    if (index != -1) {
      _skills[index] = updated;
      await _saveSkills();
      notifyListeners();
    }
  }

  Future<void> deleteSkill(String id) async {
    _skills.removeWhere((s) => s.id == id);
    await _saveSkills();
    notifyListeners();
  }

  Future<void> toggleSkill(String id) async {
    final index = _skills.indexWhere((s) => s.id == id);
    if (index != -1) {
      _skills[index] = _skills[index].copyWith(isEnabled: !_skills[index].isEnabled);
      await _saveSkills();
      notifyListeners();
    }
  }

  /// Finds matching skill based on user query
  HermesSkill? matchSkill(String userQuery) {
    final query = userQuery.toLowerCase().trim();
    for (final skill in activeSkills) {
      for (final trigger in skill.triggers) {
        if (query.contains(trigger.toLowerCase().trim())) {
          return skill;
        }
      }
    }
    return null;
  }

  /// Executes Hermes skill (Webhook, Custom Speech, or URL Scheme)
  Future<AssistantResponse> executeSkill(HermesSkill skill, [Map<String, dynamic>? args]) async {
    switch (skill.actionType) {
      case SkillActionType.webhook:
        if (skill.targetUrl == null || skill.targetUrl!.isEmpty) {
          return AssistantResponse(
            speechText: "Skill ${skill.name} has no webhook target configured.",
            source: ResponseSource.localAction,
            isSuccess: false,
          );
        }

        try {
          final uri = Uri.parse(skill.targetUrl!);
          http.Response resp;

          if (skill.httpMethod.toUpperCase() == 'GET') {
            resp = await http.get(uri).timeout(const Duration(seconds: 8));
          } else {
            final body = skill.payloadTemplate ?? jsonEncode({'action': skill.name, 'timestamp': DateTime.now().toIso8601String()});
            resp = await http.post(
              uri,
              headers: {'Content-Type': 'application/json'},
              body: body,
            ).timeout(const Duration(seconds: 8));
          }

          if (resp.statusCode >= 200 && resp.statusCode < 300) {
            return AssistantResponse(
              speechText: skill.responseSpeech,
              displayText: "${skill.responseSpeech} [HTTP ${resp.statusCode}]",
              source: ResponseSource.localAction,
              actionName: skill.name,
              actionData: {'statusCode': resp.statusCode, 'body': resp.body},
            );
          } else {
            return AssistantResponse(
              speechText: "Skill webhook returned status code ${resp.statusCode}.",
              source: ResponseSource.localAction,
              actionName: skill.name,
              isSuccess: false,
            );
          }
        } catch (e) {
          return AssistantResponse(
            speechText: "Failed to dispatch webhook for ${skill.name}.",
            source: ResponseSource.localAction,
            actionName: skill.name,
            isSuccess: false,
          );
        }

      case SkillActionType.urlScheme:
        if (skill.targetUrl != null && skill.targetUrl!.isNotEmpty) {
          final uri = Uri.parse(skill.targetUrl!);
          if (await canLaunchUrl(uri)) {
            await launchUrl(uri, mode: LaunchMode.externalApplication);
            return AssistantResponse(
              speechText: skill.responseSpeech,
              source: ResponseSource.localAction,
              actionName: skill.name,
            );
          }
        }
        return AssistantResponse(
          speechText: "Could not launch URL scheme for ${skill.name}.",
          source: ResponseSource.localAction,
          isSuccess: false,
        );

      case SkillActionType.customResponse:
        return AssistantResponse(
          speechText: skill.responseSpeech,
          source: ResponseSource.localAction,
          actionName: skill.name,
        );
    }
  }

  /// Converts active skills into dynamic Gemini Tool Function Declarations
  List<FunctionDeclaration> toGeminiToolDeclarations() {
    return activeSkills.map((skill) {
      final safeName = skill.name.toLowerCase().replaceAll(RegExp(r'[^a-z0-9_]'), '_');
      return FunctionDeclaration(
        safeName,
        skill.description.isNotEmpty ? skill.description : "Trigger skill ${skill.name}",
        Schema(SchemaType.object),
      );
    }).toList();
  }

  /// Default demo skills inspired by Hermes and Home Assistant
  List<HermesSkill> _getDefaultSkills() {
    return [
      HermesSkill(
        id: 'skill_smart_light',
        name: 'Bedroom Smart Light',
        description: 'Triggers Home Assistant or IoT smart light in bedroom',
        triggers: ['bedroom light', 'kamre ki light', 'smart light', 'room lights'],
        actionType: SkillActionType.customResponse,
        responseSpeech: "Bedroom smart light protocol activated, Boss.",
      ),
      HermesSkill(
        id: 'skill_daily_briefing',
        name: 'Daily Status Briefing',
        description: 'Provides a complete diagnostic overview of morning status',
        triggers: ['good morning', 'shubh prabhat', 'morning briefing', 'daily update'],
        actionType: SkillActionType.customResponse,
        responseSpeech: "Good morning, Boss. All SAKTI neural modules are operational. Power and connectivity are nominal.",
      ),
      HermesSkill(
        id: 'skill_security_lockdown',
        name: 'Security Lockdown',
        description: 'Triggers emergency lockdown or privacy mode',
        triggers: ['lockdown', 'red alert', 'privacy mode', 'secure system'],
        actionType: SkillActionType.customResponse,
        responseSpeech: "Security protocol active. All telemetry locked down.",
      ),
    ];
  }
}
