import 'package:battery_plus/battery_plus.dart';
import 'package:external_app_launcher/external_app_launcher.dart';
import 'package:intl/intl.dart';
import 'package:torch_light/torch_light.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/assistant_response.dart';

class LocalActionsService {
  final Battery _battery = Battery();

  /// Toggles or sets the device torch / flashlight
  Future<AssistantResponse> toggleFlashlight({required bool turnOn}) async {
    try {
      final isAvailable = await TorchLight.isTorchAvailable();
      if (!isAvailable) {
        return AssistantResponse(
          speechText: "Flashlight is not available on this device.",
          source: ResponseSource.localAction,
          isSuccess: false,
        );
      }

      if (turnOn) {
        await TorchLight.enableTorch();
        return AssistantResponse(
          speechText: "Flashlight turned on, Boss.",
          source: ResponseSource.localAction,
          actionName: 'flashlight_on',
        );
      } else {
        await TorchLight.disableTorch();
        return AssistantResponse(
          speechText: "Flashlight turned off.",
          source: ResponseSource.localAction,
          actionName: 'flashlight_off',
        );
      }
    } catch (e) {
      return AssistantResponse(
        speechText: "Could not control the flashlight: ${e.toString()}",
        source: ResponseSource.localAction,
        isSuccess: false,
      );
    }
  }

  /// Gets current battery percentage and charging status
  Future<AssistantResponse> getBatteryStatus() async {
    try {
      final level = await _battery.batteryLevel;
      final state = await _battery.batteryState;
      final isCharging = state == BatteryState.charging;

      String message = "Your battery is at $level percent";
      if (isCharging) {
        message += " and currently charging.";
      } else if (level <= 20) {
        message += ". Battery is low, Boss. Consider plugging in a charger.";
      } else {
        message += ". Power levels are optimal.";
      }

      return AssistantResponse(
        speechText: message,
        source: ResponseSource.localAction,
        actionName: 'get_battery',
        actionData: {'level': level, 'charging': isCharging},
      );
    } catch (e) {
      return AssistantResponse(
        speechText: "Unable to read battery status at the moment.",
        source: ResponseSource.localAction,
        isSuccess: false,
      );
    }
  }

  /// Tells current time in natural spoken format
  AssistantResponse getCurrentTime() {
    final now = DateTime.now();
    final timeStr = DateFormat('h:mm a').format(now);
    return AssistantResponse(
      speechText: "The time is $timeStr.",
      source: ResponseSource.localAction,
      actionName: 'get_time',
      actionData: {'time': timeStr},
    );
  }

  /// Tells current date
  AssistantResponse getCurrentDate() {
    final now = DateTime.now();
    final dateStr = DateFormat('EEEE, MMMM d, y').format(now);
    return AssistantResponse(
      speechText: "Today is $dateStr.",
      source: ResponseSource.localAction,
      actionName: 'get_date',
      actionData: {'date': dateStr},
    );
  }

  /// Opens popular apps by package name or URL scheme
  Future<AssistantResponse> openApp(String appName) async {
    final nameLower = appName.toLowerCase().trim();

    final appPackages = {
      'youtube': 'com.google.android.youtube',
      'whatsapp': 'com.whatsapp',
      'chrome': 'com.android.chrome',
      'browser': 'com.android.chrome',
      'settings': 'com.android.settings',
      'camera': 'com.google.android.GoogleCamera',
      'maps': 'com.google.android.apps.maps',
      'spotify': 'com.spotify.music',
      'telegram': 'org.telegram.messenger',
      'instagram': 'com.instagram.android',
    };

    String? targetPackage;
    for (final entry in appPackages.entries) {
      if (nameLower.contains(entry.key)) {
        targetPackage = entry.value;
        break;
      }
    }

    if (targetPackage != null) {
      try {
        final result = await LaunchApp.openApp(
          androidPackageName: targetPackage,
          openStore: false,
        );
        return AssistantResponse(
          speechText: "Opening $appName, Boss.",
          source: ResponseSource.localAction,
          actionName: 'open_app',
          actionData: {'package': targetPackage, 'result': result},
        );
      } catch (e) {
        // Fallback to web search if app open fails
      }
    }

    // Fallback: search on web
    return searchWeb(appName);
  }

  /// Searches the web via default browser
  Future<AssistantResponse> searchWeb(String query) async {
    final url = Uri.parse("https://www.google.com/search?q=${Uri.encodeComponent(query)}");
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
      return AssistantResponse(
        speechText: "Searching the web for $query.",
        source: ResponseSource.localAction,
        actionName: 'web_search',
        actionData: {'query': query},
      );
    }

    return AssistantResponse(
      speechText: "Sorry, I could not launch the browser.",
      source: ResponseSource.localAction,
      isSuccess: false,
    );
  }
}
