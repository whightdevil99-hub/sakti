import 'package:google_generative_ai/google_generative_ai.dart';
import '../models/assistant_response.dart';
import '../models/memory_item.dart';
import 'local_actions_service.dart';
import 'memory_service.dart';

class GeminiService {
  final String apiKey;
  final LocalActionsService localActions;
  final MemoryService? memoryService;
  GenerativeModel? _model;
  ChatSession? _chatSession;

  GeminiService({
    required this.apiKey,
    required this.localActions,
    this.memoryService,
  }) {
    _initializeModel();
  }

  void _initializeModel() {
    final adaptiveContext = memoryService?.buildAdaptivePromptContext() ?? "";

    // SAKTI Persona & System Instruction with Self-Improving Memory
    final systemInstruction = Content.system(
      '''
You are SAKTI, an ultra-intelligent, sharp, and loyal AI Assistant inspired by Jarvis, Alexa, and Hermes.
Your creator and user is "Boss".
Personality:
- Confident, polite, high-tech, and crisp.
- Keep your spoken responses concise and punchy (1-3 sentences) suitable for Text-to-Speech audio feedback.
- When an action is required (e.g. flashlight, battery check, launching apps, opening YouTube/WhatsApp), invoke the relevant tool call.
- Always be ready to assist with deep knowledge, coding, life queries, and smart device actions.
- SELF-IMPROVEMENT & MEMORY:
  * When Boss tells you to remember something (a fact, preference, date, or name), invoke the `remember_fact` tool.
  * When Boss corrects you or provides feedback on how you should behave, invoke `record_user_correction`.
$adaptiveContext
''',
    );

    // Tools / Function Declarations for SAKTI
    final tools = [
      Tool(
        functionDeclarations: [
          FunctionDeclaration(
            'toggle_flashlight',
            'Turn the phone flashlight on or off',
            Schema(
              SchemaType.object,
              properties: {
                'turnOn': Schema(
                  SchemaType.boolean,
                  description: 'True to turn on flashlight, False to turn off',
                ),
              },
              requiredProperties: ['turnOn'],
            ),
          ),
          FunctionDeclaration(
            'get_battery_status',
            'Get current battery percentage and charging state',
            Schema(SchemaType.object),
          ),
          FunctionDeclaration(
            'get_current_time',
            'Get current local time',
            Schema(SchemaType.object),
          ),
          FunctionDeclaration(
            'get_current_date',
            'Get current local date',
            Schema(SchemaType.object),
          ),
          FunctionDeclaration(
            'open_app',
            'Open a mobile application such as YouTube, WhatsApp, Camera, Chrome, etc.',
            Schema(
              SchemaType.object,
              properties: {
                'appName': Schema(
                  SchemaType.string,
                  description: 'Name of the application to open',
                ),
              },
              requiredProperties: ['appName'],
            ),
          ),
          FunctionDeclaration(
            'search_web',
            'Search the internet or Google for information',
            Schema(
              SchemaType.object,
              properties: {
                'query': Schema(
                  SchemaType.string,
                  description: 'The search term or query',
                ),
              },
              requiredProperties: ['query'],
            ),
          ),
          FunctionDeclaration(
            'remember_fact',
            'Store a fact, preference, or detail about Boss into long-term neural memory',
            Schema(
              SchemaType.object,
              properties: {
                'fact': Schema(
                  SchemaType.string,
                  description: 'The fact or preference to remember',
                ),
              },
              requiredProperties: ['fact'],
            ),
          ),
          FunctionDeclaration(
            'record_user_correction',
            'Record a behavioral correction or rule from Boss to improve future responses',
            Schema(
              SchemaType.object,
              properties: {
                'mistake': Schema(
                  SchemaType.string,
                  description: 'The previous mistake or behavior to avoid',
                ),
                'correction': Schema(
                  SchemaType.string,
                  description: 'The correct behavior or rule to follow',
                ),
              },
              requiredProperties: ['mistake', 'correction'],
            ),
          ),
        ],
      )
    ];

    _model = GenerativeModel(
      model: 'gemini-1.5-flash',
      apiKey: apiKey,
      systemInstruction: systemInstruction,
      tools: tools,
    );

    _chatSession = _model!.startChat();
  }

  /// Sends user prompt to Gemini and handles potential Tool / Function Calling
  Future<AssistantResponse> ask(String prompt) async {
    if (_chatSession == null) {
      _initializeModel();
    }

    try {
      var response = await _chatSession!.sendMessage(Content.text(prompt));

      // Check if Gemini invoked a function / tool
      final functionCalls = response.functionCalls.toList();
      if (functionCalls.isNotEmpty) {
        final call = functionCalls.first;
        final toolResult = await _executeTool(call.name, call.args);

        // Send function execution result back to Gemini for conversational final speech
        final followUp = await _chatSession!.sendMessage(
          Content.functionResponse(
            call.name,
            {'result': toolResult.speechText, 'isSuccess': toolResult.isSuccess},
          ),
        );

        final finalText = followUp.text?.trim() ?? toolResult.speechText;
        return AssistantResponse(
          speechText: finalText,
          displayText: finalText,
          source: ResponseSource.cloudGemini,
          actionName: call.name,
          actionData: call.args,
          isSuccess: toolResult.isSuccess,
        );
      }

      final text = response.text?.trim() ?? "Understood, Boss.";
      return AssistantResponse(
        speechText: text,
        displayText: text,
        source: ResponseSource.cloudGemini,
      );
    } catch (e) {
      return AssistantResponse(
        speechText: "I encountered a communication glitch: ${e.toString()}",
        source: ResponseSource.cloudGemini,
        isSuccess: false,
      );
    }
  }

  /// Executes device tool or self-improving memory based on Gemini's function call decision
  Future<AssistantResponse> _executeTool(String name, Map<String, dynamic> args) async {
    switch (name) {
      case 'toggle_flashlight':
        final turnOn = args['turnOn'] as bool? ?? false;
        return await localActions.toggleFlashlight(turnOn: turnOn);

      case 'get_battery_status':
        return await localActions.getBatteryStatus();

      case 'get_current_time':
        return localActions.getCurrentTime();

      case 'get_current_date':
        return localActions.getCurrentDate();

      case 'open_app':
        final appName = args['appName'] as String? ?? '';
        return await localActions.openApp(appName);

      case 'search_web':
        final query = args['query'] as String? ?? '';
        return await localActions.searchWeb(query);

      case 'remember_fact':
        final fact = args['fact'] as String? ?? '';
        if (memoryService != null && fact.isNotEmpty) {
          await memoryService!.rememberFact(fact, type: MemoryType.fact);
          return AssistantResponse(
            speechText: "Learned and committed to neural memory, Boss: $fact",
            source: ResponseSource.localAction,
            actionName: 'remember_fact',
          );
        }
        return AssistantResponse(
          speechText: "Acknowledged, Boss.",
          source: ResponseSource.localAction,
        );

      case 'record_user_correction':
        final mistake = args['mistake'] as String? ?? '';
        final correction = args['correction'] as String? ?? '';
        if (memoryService != null) {
          await memoryService!.recordCorrection(mistake: mistake, correction: correction);
          return AssistantResponse(
            speechText: "Correction noted, Boss. I have adapted my behavioral protocol.",
            source: ResponseSource.localAction,
            actionName: 'learn_correction',
          );
        }
        return AssistantResponse(
          speechText: "Understood, Boss. Updating behavior.",
          source: ResponseSource.localAction,
        );

      default:
        return AssistantResponse(
          speechText: "Command $name executed.",
          source: ResponseSource.localAction,
        );
    }
  }

  /// Reset conversation session
  void clearHistory() {
    if (_model != null) {
      _chatSession = _model!.startChat();
    }
  }
}
