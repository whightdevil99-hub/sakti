enum MemoryType {
  fact,
  correction,
  preference,
  learnedSkill,
}

class MemoryItem {
  final String id;
  final MemoryType type;
  final String content;
  final String? context;
  final DateTime createdAt;
  final int confidenceScore;

  MemoryItem({
    required this.id,
    required this.type,
    required this.content,
    this.context,
    required this.createdAt,
    this.confidenceScore = 1,
  });

  MemoryItem copyWith({
    String? id,
    MemoryType? type,
    String? content,
    String? context,
    DateTime? createdAt,
    int? confidenceScore,
  }) {
    return MemoryItem(
      id: id ?? this.id,
      type: type ?? this.type,
      content: content ?? this.content,
      context: context ?? this.context,
      createdAt: createdAt ?? this.createdAt,
      confidenceScore: confidenceScore ?? this.confidenceScore,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type.name,
      'content': content,
      'context': context,
      'createdAt': createdAt.toIso8601String(),
      'confidenceScore': confidenceScore,
    };
  }

  factory MemoryItem.fromJson(Map<String, dynamic> json) {
    return MemoryItem(
      id: json['id'] as String,
      type: MemoryType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => MemoryType.fact,
      ),
      content: json['content'] as String,
      context: json['context'] as String?,
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      confidenceScore: json['confidenceScore'] as int? ?? 1,
    );
  }
}
