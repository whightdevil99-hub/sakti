enum ResponseSource {
  localAction,
  cloudGemini,
  fallback,
}

class AssistantResponse {
  final String speechText;
  final String? displayText;
  final ResponseSource source;
  final String? actionName;
  final Map<String, dynamic>? actionData;
  final bool isSuccess;

  AssistantResponse({
    required this.speechText,
    this.displayText,
    required this.source,
    this.actionName,
    this.actionData,
    this.isSuccess = true,
  });

  @override
  String toString() {
    return 'AssistantResponse(speechText: $speechText, source: $source, action: $actionName)';
  }
}
