enum SkillActionType {
  webhook,
  customResponse,
  urlScheme,
}

class HermesSkill {
  final String id;
  final String name;
  final String description;
  final List<String> triggers;
  final SkillActionType actionType;
  final String? targetUrl;
  final String httpMethod; // 'GET' or 'POST'
  final String? payloadTemplate;
  final String responseSpeech;
  final bool isEnabled;

  HermesSkill({
    required this.id,
    required this.name,
    required this.description,
    required this.triggers,
    required this.actionType,
    this.targetUrl,
    this.httpMethod = 'POST',
    this.payloadTemplate,
    required this.responseSpeech,
    this.isEnabled = true,
  });

  HermesSkill copyWith({
    String? id,
    String? name,
    String? description,
    List<String>? triggers,
    SkillActionType? actionType,
    String? targetUrl,
    String? httpMethod,
    String? payloadTemplate,
    String? responseSpeech,
    bool? isEnabled,
  }) {
    return HermesSkill(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      triggers: triggers ?? this.triggers,
      actionType: actionType ?? this.actionType,
      targetUrl: targetUrl ?? this.targetUrl,
      httpMethod: httpMethod ?? this.httpMethod,
      payloadTemplate: payloadTemplate ?? this.payloadTemplate,
      responseSpeech: responseSpeech ?? this.responseSpeech,
      isEnabled: isEnabled ?? this.isEnabled,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'triggers': triggers,
      'actionType': actionType.name,
      'targetUrl': targetUrl,
      'httpMethod': httpMethod,
      'payloadTemplate': payloadTemplate,
      'responseSpeech': responseSpeech,
      'isEnabled': isEnabled,
    };
  }

  factory HermesSkill.fromJson(Map<String, dynamic> json) {
    return HermesSkill(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String? ?? '',
      triggers: List<String>.from(json['triggers'] ?? []),
      actionType: SkillActionType.values.firstWhere(
        (e) => e.name == json['actionType'],
        orElse: () => SkillActionType.customResponse,
      ),
      targetUrl: json['targetUrl'] as String?,
      httpMethod: json['httpMethod'] as String? ?? 'POST',
      payloadTemplate: json['payloadTemplate'] as String?,
      responseSpeech: json['responseSpeech'] as String? ?? 'Skill executed, Boss.',
      isEnabled: json['isEnabled'] as bool? ?? true,
    );
  }
}
