package com.example.sakti

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
